object sample {
  /*
import com.typesafe.config.ConfigFactory
import scala.collection.mutable.ListBuffer
//import org.apache.spark.sql.SparkSession
import scala.collection.mutable.ArrayBuffer
object Main {
  def main(args:Array[String]){
    val x = args(1)
    if(args(0)=="Mean") {
      lazy val value = ConfigFactory.load().getString("my.file.location")
      val bufferedSource = io.Source.fromFile(value)
      var count =0
      var summation = 0
      val cols = ""
      var mean = 1
      var fruits = ArrayBuffer[String]()
      for (line <- bufferedSource.getLines) {
        def cols:Array[String] = line.split(",").map(_.trim)
        fruits += cols(0)}

      println(fruits(0),"line")
      if(fruits(0) == args(1))
        for(i <- 1 until fruits.length)
          {
            count = count + 1
            summation=summation+fruits(i).toInt
            mean = mean * (summation / count)
          }
      println(s"mean of column $x is:  $mean")

      bufferedSource.close
    }

  }}

 */

}
